Smart AI Solutions skills from the GTP ECO workshop.

smart-ai-ad-ideas: ad ideas and ad copy, written from what you sell.
smart-ai-unslop: takes the AI sound out of your writing, so it sounds like you.
smart-ai-trends: what people said about a topic on YouTube, Reddit and X in the last 30 days.
smart-ai-funnels: maps your sales and support funnel, then writes every WhatsApp and email step.

claude.ai: upload each zip in upload-to-claude/ under Customize > Skills.
Claude Code: copy each folder into ~/.claude/skills/.
