The three skills used live on stage at the GTP ECO workshop.

ad-creative: ad ideas and ad copy.
slopmonster: takes the AI sound out of your writing.
last30days: what people said about a topic on YouTube, Reddit and X in the last 30 days (needs its own API keys, see its SKILL.md).

claude.ai: upload each zip in upload-to-claude/ under Customize > Skills.
Claude Code: copy each folder into ~/.claude/skills/.
Each skill keeps its own MIT licence in its folder.
