# Install a marketing skill in Claude

Start with step 1 on a computer. One skill takes about 3 minutes.

You need a Claude account. The free plan works. Each skill zip is under 15 KB, so it uses almost no data.

## Step 1. Switch on file creation (1 minute)

1. Open <https://claude.ai> in your browser and sign in.
2. Go to **Settings > Capabilities**.
3. Switch on **Code execution and file creation**. In the newer layout it is called **Create and edit files**.

## Step 2. Upload one skill (1 minute per skill)

1. Unzip `anthropic-marketing-skills.zip`. Open the `upload-to-claude` folder.
2. In Claude, go to **Customize > Skills**.
3. Click **+**, then **+ Create skill**, then **Upload a skill**.
4. Choose one zip, for example `campaign-plan.zip`. Upload the zip as it is. Do not unzip it.
5. Repeat for each skill you want. One zip is one skill.

## Step 3. Use it (1 minute)

1. Check that the switch next to the skill is on.
2. Start a new chat and name the skill in your request, for example:
   > Use the campaign-plan skill to plan four weeks of Facebook and WhatsApp posts for my bakery in Durban.

## Which skill does what

| Skill | Use it to |
|---|---|
| brand-review | check a post or page against your brand voice before it goes out |
| campaign-plan | turn a goal into a week-by-week campaign plan |
| competitive-brief | compare your business with a competitor |
| content-creation | write posts, emails and web pages in the right format for each channel |
| draft-content | draft one piece of content with headline options |
| email-sequence | write a series of follow-up emails |
| performance-report | turn your numbers into a short report with next steps |
| seo-audit | find what to fix so people find your website on Google |

## If an upload fails

Claude shows the reason. The Claude Help Center lists the common ones (size, folder name, missing SKILL.md, characters in the name or description):
<https://support.claude.com/en/articles/12512180-use-skills-in-claude>

## Already use Claude Code? (optional)

Install Anthropic's whole marketing plugin instead. Type these two commands in your terminal:

```
claude plugin marketplace add anthropics/knowledge-work-plugins
claude plugin install marketing@knowledge-work-plugins
```

Then type `/` in Claude Code and look for `/marketing:campaign-plan`. The plugin route installs the newest upstream version, not the pinned copy in this zip, and it also offers connectors to other apps.

Steps checked against the Claude Help Center and Claude Code docs on 27 October 2026. Menu names can change; the Help Center link above has the current wording.

Next: upload `campaign-plan.zip` and ask it to plan your next month.
