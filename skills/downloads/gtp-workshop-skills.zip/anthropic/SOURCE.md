# Source

- Upstream folder at the pinned commit: <https://github.com/anthropics/knowledge-work-plugins/tree/c71b6f3082b1e5ace3d1a9e30ac9205934134c9c/marketing>
- Commit: `c71b6f3082b1e5ace3d1a9e30ac9205934134c9c` (21 September 2026)
- Repository: <https://github.com/anthropics/knowledge-work-plugins>
- Licence: Apache-2.0 (see `LICENSE`)

## Files and SHA-256

| File in this zip | Upstream path | SHA-256 |
|---|---|---|
| `marketing-skills/brand-review/SKILL.md` | `marketing/skills/brand-review/SKILL.md` | `759f29397a908c32521080247292a4e1c52ac01643bea70ccd6e807e86c1fa4b` |
| `marketing-skills/campaign-plan/SKILL.md` | `marketing/skills/campaign-plan/SKILL.md` | `f0b146074b64ee0fd52f7864e30191eab83878c8c1e3e7cf24754e13c7dbfad3` |
| `marketing-skills/competitive-brief/SKILL.md` | `marketing/skills/competitive-brief/SKILL.md` | `c1e5442facbc3206ac6a77392bef009fe9aff4ba7c2678e2f4118be2f6be82b3` |
| `marketing-skills/content-creation/SKILL.md` | `marketing/skills/content-creation/SKILL.md` | `17f0bfd536502a91c760accaa1ae6c0c76c3812973571729664133e282c5dded` |
| `marketing-skills/draft-content/SKILL.md` | `marketing/skills/draft-content/SKILL.md` | `0bfe029dcc039ff71a76b0fec3c5d900fba0e447eb9dcd505ab25b14be3577fd` |
| `marketing-skills/email-sequence/SKILL.md` | `marketing/skills/email-sequence/SKILL.md` | `4303252cbe340b19945b3e58d46430fdf42ea47b3e26d985e3ef1d6da5e36021` |
| `marketing-skills/performance-report/SKILL.md` | `marketing/skills/performance-report/SKILL.md` | `997397e23ba5124cdcbbf17e4be9f5cb36f2a2145b5648e02b2852c91c3cc140` |
| `marketing-skills/seo-audit/SKILL.md` | `marketing/skills/seo-audit/SKILL.md` | `25008ccdda6f4d9b7ba05f11120d0b9cc976c2d0b04f3d86605e63b1a54a8c40` |
| `LICENSE` | `marketing/LICENSE` | `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30` |
